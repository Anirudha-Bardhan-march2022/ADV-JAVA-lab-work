package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Base64;
import java.util.Base64.Encoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register.cdac")
public class RegistrationServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Jdbc code to insert the data
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/panki", "root", "new_password");
			PreparedStatement st = conn.prepareStatement("insert into tbl_customer(name, email, mobileNo, username, password) values(?, ?, ?, ?, ?)");
			//substituting ? with actual value
			
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			int mobileNo = Integer.parseInt(request.getParameter("mobileNo"));
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			Encoder encoder = Base64.getEncoder();
			String encodedString = encoder.encodeToString(password.getBytes());
			
			System.out.println(encodedString);
			
			Encoder encoder1 = Base64.getEncoder();
			String encodedString1 = encoder1.encodeToString(username.getBytes());
			
			System.out.println(encodedString1);
			
			String strQuery = "select count(*) from tbl_customer where email ='"+email+"'";
			ResultSet rs = st.executeQuery(strQuery);
			rs.next();
			String Countrow = rs.getString(1);	
			
			if(Countrow.equals("0"))
			{
				
				st.setString(1, name); 
				st.setString(2, email);
				st.setInt(3, mobileNo);
				st.setString(4, encodedString1);
				st.setString(5, encodedString);
				
				int i = st.executeUpdate("insert into tbl_customer(name, email, mobileno, username, password) values('"+name+"','"+email+"','"+mobileNo+"','"+encodedString1+"','"+encodedString+"')");
				
				System.out.println("Updated : "+i);
				
				PrintWriter out = response.getWriter();
				out.write("<html><body>");
				out.write("<h1>Registration successful!</h1>");
				out.write("</body></html>");
								
			}else{
				
				PrintWriter out = response.getWriter();
				out.write("<html><body>");
				out.write("<h1>User name or Email already exists !</h1>");
				out.write("</body></html>");
				
				System.out.println("The matches found in row number in tbl_customer is "+" "+Countrow);
				
			}
			
			conn.close();
			
		}catch(Exception e){
			
			e.printStackTrace();
		}
	}
}


