package com.cdac.servlet;


import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/age.cdac")
public class AgeServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
			   try {
						//Reading date of birth from the user
					   	String dob = request.getParameter("dob");
				      
				      	//Converting String to Date
				       	SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				       	Date date = formatter.parse(dob);
				      	
				      	//Converting obtained Date object to LocalDate object
					    Instant instant = date.toInstant();
					    ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
					    LocalDate givenDate = zone.toLocalDate();
					      
					    //Calculating the difference between given date to current date.
					    Period period = Period.between(givenDate, LocalDate.now());
					    
					    if(request.getParameter("onlyyear") != null)
					    {					    
					    	PrintWriter out = response.getWriter();
						   	out.write("<html><body>");
					    	out.write("<h1>Age : "+period.getYears()+" years "+"</h1>");
					    	out.write("</body></html>");
					      
					    	System.out.print(period.getYears()+" years ");
					    
					    }else if(request.getParameter("fullage") != null){
					    	
					    	PrintWriter out = response.getWriter();
							out.write("<html><body>");
							out.write("<h1>Age : "+period.getYears()+" years "+period.getMonths()+" Months "+period.getDays()+" days"+"</h1>");
							out.write("</body></html>");
						      
						    System.out.print(period.getYears()+" years "+period.getMonths()+" and "+period.getDays()+" days");
						    
					    }
				    				   					      
				} catch (ParseException e) {
					
					e.printStackTrace();
				}
				
			}	      
			      
		}
