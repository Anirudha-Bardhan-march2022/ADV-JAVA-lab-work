package com.cdac.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.service.LoginService;
import com.cdac.service.LoginService1;


@WebServlet("/login1.cdac")
public class UserLoginServlet1 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		LoginService1 loginService = new LoginService1();
		
		boolean isValid = loginService.isValidUser(username, password);
		
		if(isValid)
		{
			String rememberMe = request.getParameter("rememberMe");
			
			if((rememberMe != null) && rememberMe.equals("yes"))
			{
				Cookie c = new Cookie("uname",username);
				c.setMaxAge(60 * 60 * 24);
				
				Cookie c1 = new Cookie("upass",password);
				c1.setMaxAge(60 * 60 * 24);
				
				response.addCookie(c);
				response.addCookie(c1);
			}
			
			response.sendRedirect("welcome.html");
			
		}else{
			
			response.sendRedirect("login1.html");
		}
	}
}
