package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/TatkalBookingServlet1")
public class TatkalBookingServlet1 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		ServletConfig cfg = getServletConfig();
		LocalTime startTime = LocalTime.parse(cfg.getInitParameter("startTime"));
		
		LocalTime timeRightNow = LocalTime.now();
		
		
		if(timeRightNow.isAfter(startTime))
			out.write("<h1>You are on time, please proceed with the booking</h1>");
		else
			out.write("<h1>Sorry, Tatkal booking not allowed right now!</h1>");
	}
}
