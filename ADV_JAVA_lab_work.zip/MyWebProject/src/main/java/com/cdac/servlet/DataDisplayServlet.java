package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DataDisplayServlet")
public class DataDisplayServlet extends HttpServlet {
	
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			
			PrintWriter out = response.getWriter(); 
			response.setContentType("text/html");  
	        out.println("<html><body>");  
	        
	        try 
	         {  
	        	//connecting to the db
	        	Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/panki", "root", "new_password");  
				Statement stmt = conn.createStatement();  
				ResultSet rs = stmt.executeQuery("select * from tbl_customer");  

				//generating a table
				out.write("<table border = 1 width = 50% height = 50%>"); 
	            out.write("<tr><th>Name</th><th>Email</th><th>MobileNo</th><th>UserName</th><th>Password</th></tr>");  
	            
	            while (rs.next()) 
	            {  	            	
	                 String name = rs.getString("name");  
	                 String email = rs.getString("email"); 
	                 int mobileNo = rs.getInt("mobileNo"); 
	                 String username = rs.getString("username"); 
	                 String password = rs.getString("password"); 
	                 
	                 out.write("<tr><td>"+name+"</td><td>"+email+"</td><td>"+mobileNo+"</td><td>"+username+"</td><td>"+password+"</td></tr>");   
	             }  
	            
	             out.write("</table>");  
	             out.write("</body></html>");  
	             
	             conn.close();  
	            }catch(Exception e) {
	        
	             out.write("error");  
	         }  
	     } 
	}
	

	