package com.cdac.service;

public class LoginService {

	public boolean isValidUser(String username, String password) {
		
		if(username.equals("Anirudha Bardhan") && password.equals("1234"))
		{
			return true;
		}
		
		return false;
	}
}
