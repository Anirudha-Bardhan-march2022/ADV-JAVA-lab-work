package com.cdac.service;

public class LoginService1 {

	public boolean isValidUser(String username, String password) {
		
		if(username.equals("Anirudha") && password.equals("4343"))
		{
			return true;
		}
		
		return false;
	}
}
