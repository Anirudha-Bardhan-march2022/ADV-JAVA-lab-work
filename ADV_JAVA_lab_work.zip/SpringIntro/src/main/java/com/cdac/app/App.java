package com.cdac.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.component.ATM;
import com.cdac.component.AddSub;
import com.cdac.component.HelloAni;
import com.cdac.component.LoginService;
import com.cdac.component.MotorCar;
import com.cdac.component.TextEditor;
import com.cdac.component.WesternUnion;

public class App {

	public static void main(String[] args) {
		
		//Loading Spring/IOC Container
		ApplicationContext ctx = new ClassPathXmlApplicationContext("myspringconfigure.xml");
		
		//Accessing a particular bean
		HelloAni hw = (HelloAni) ctx.getBean("hello");
		
		System.out.println(hw.sayHello("Majrul"));
		
		//But why are we using Spring to create object of HelloWorld class?
		//We could have created object on our own like this:
		//HelloWorld hw = new HelloWorld();
		
		AddSub as = (AddSub) ctx.getBean("calc");
		
		System.out.println(as.add(10, 20));
		System.out.println(as.sub(10, 20));
		
		WesternUnion cc = (WesternUnion) ctx.getBean("currencyConv");
		
		System.out.println(cc.convert("USD", "INR", 650));
		
		LoginService loginServ = (LoginService) ctx.getBean("loginServ");
		
		System.out.println(loginServ.isValidUser("majrul", "456"));
		
		TextEditor te = (TextEditor) ctx.getBean("txtEdtr");
		te.load("abc.txt");
		
		MotorCar car = (MotorCar) ctx.getBean("car");
		car.drive();
		
		ATM atm = (ATM) ctx.getBean("hdfcAtm");
		atm.withdraw(20202020, 5000);
	
	  }
  }
