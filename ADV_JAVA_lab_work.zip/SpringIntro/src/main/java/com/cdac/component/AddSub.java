package com.cdac.component;

public class AddSub {
	
	public int add(int x, int y) {
		
		return x + y;
	}

	public int sub(int x, int y) {
		
		return x - y;
	}
}
