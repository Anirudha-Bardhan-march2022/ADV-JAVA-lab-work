package com.cdac.component;

public class HelloAni {

	public String sayHello(String name) {
		
		return "Hello  " +name;
	}
}
