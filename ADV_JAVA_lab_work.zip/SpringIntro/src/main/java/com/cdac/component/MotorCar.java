package com.cdac.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("car")
public class MotorCar {
	
	@Autowired
	private CarEngine engine;
	
	public void drive() {
		engine.on();
		engine.off();
	}
}
