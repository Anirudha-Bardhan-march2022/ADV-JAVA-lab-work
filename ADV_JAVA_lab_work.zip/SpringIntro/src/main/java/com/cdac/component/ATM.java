package com.cdac.component;

public interface ATM {
	
	public void withdraw(int acno, double amount);
}
