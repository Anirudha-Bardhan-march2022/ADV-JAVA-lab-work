package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("splChkr")
public class CheckSpel {
	
	public void checkSpellingMistakes(String document) {
		
		System.out.println("some code here for checking spelling mistakes in " +document);
	}
}
