package com.cdac.component;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Appli {
	
	public static void main(String[] args) {
		
		//Loading Spring/IOC Container
		ApplicationContext ctx = new ClassPathXmlApplicationContext("myspringconfigure.xml");
		
		CarPartsInvtory inv = (CarPartsInvtory) ctx.getBean("carParts2");
		
		//model/entity classes are not instantiated using Spring
		CarPart cp = new CarPart();
		
		cp.setPartName("Back Light");
		cp.setCarModel("Maruti 800");
		cp.setPrice(107500);
		cp.setQuantity(100);
		
		long ms1 = System.currentTimeMillis();
		inv.addNewPart(cp);
		long ms2 = System.currentTimeMillis();
		System.out.println("Total time taken : "+(ms2 - ms1)+" ms approx");
		
	}
}
