package com.cdac.component;

import java.util.List;

public interface CarParts {
	
	public void addNewPart(CarPart carPart);
	public List<CarPart> getAvailableParts();
}
