package Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Onlinequestions.LoaderQuestionaire;
import Onlinequestions.Question;


@WebServlet("/LoaderQuestionaireServlet")
public class LoaderQuestionaireServlet extends HttpServlet {
	
	int qNo = 0;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			LoaderQuestionaire qbLoader = new LoaderQuestionaire();
			List<Question> questions = qbLoader.loadQuestionsOnJava();
			
			if(qNo < questions.size()) 
			{
				Question question = questions.get(qNo++);
				
				HttpSession session = request.getSession();
				session.setAttribute("currentQs", question);
				
				response.sendRedirect("viewQuestions.jsp");
			}
			else
				
				response.sendRedirect("viewScore.jsp");
		}
	}