package Onlinequestions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Questionaire {

	//key-value pair (subject name -> key, questions of that subject -> value)
	private Map<String, List<Question>> questionaire = new HashMap<>();

	/* not recommended approach because would be specific subject oriented
	private List<Question> questionsOnJava;
	private List<Question> questionsOnPython;
	private List<Question> questionsOnHTML;
	private List<Question> questionsOnReact; */
	
	public void addNewSubject(String subject) {
		
		questionaire.put(subject, new ArrayList<>());
	}

	public void addNewQuestion(String subject, Question question) {
		
		List<Question> questions = questionaire.get(subject);
		questions.add(question);
	}
	
	public List<Question> fetchQuestionsOn(String subject) {
		
		return questionaire.get(subject);
	}
}
